package com.test.task.Server.Data

class ListVideo (
    var file_url: String? = null,
    var small_thumbnail_url: String? = null)